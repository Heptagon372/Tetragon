#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
쿠팡 상품 스크래퍼 (단일 파일, 자립 실행)
=========================================

Akamai Bot Manager 보호를 뚫는 검증된 레시피를 담은 독립 스크립트.
Tetragon 프로젝트와 별개로 이 파일 하나만 있으면 돈다.

■ 우회 원리 (실측으로 검증됨)
  ① Scrapling StealthyFetcher = patchright 엔진 (CDP Runtime.enable 누수 패치)
  ② headless=False  → 실제 창(headed). 이게 통과의 결정적 변수. headless면 403.
  ③ real_chrome=True → 시스템에 설치된 진짜 Google Chrome 사용
  ④ 홈 25초 대기 → 목표 이동 : Akamai 센서가 _abck를 "검증됨"으로 승격시킨 뒤 이동

■ 설치 (최초 1회)
    pip install "scrapling[all]"
    scrapling install
    patchright install --force chromium
  (시스템에 Google Chrome이 설치돼 있어야 함 — real_chrome 사용)

■ 사용법
    python coupang_scraper.py "무선마우스"                 # 검색어로 여러 상품
    python coupang_scraper.py "무선마우스" --limit 5       # 최대 5개 상세 수집
    python coupang_scraper.py 9179029564                  # 상품 ID 하나
    python coupang_scraper.py https://www.coupang.com/vp/products/9179029564
    python coupang_scraper.py "무선마우스" --wait 25 --headless   # (비권장) headless
    python coupang_scraper.py "무선마우스" --proxy http://ID:PW@host:port  # 주거용 프록시

  결과는 콘솔 출력 + coupang_result.json 저장.

■ 주의
  - headed(창 뜸)가 기본. 창은 그대로 두고 건드리지 말 것. 무인 서버는 Xvfb 필요.
  - 같은 IP로 과도하게 반복하면 Akamai가 rate-limit(403)을 건다. 그때는 IP를
    바꾸거나(휴대폰 핫스팟 등) 잠시 쉬었다 실행. 프록시는 --proxy로.
"""

import sys
import re
import json
import time
import argparse
from urllib.parse import urlparse, quote

try:
    from scrapling.fetchers import StealthyFetcher
    from playwright.sync_api import Page
except ImportError:
    print("의존성이 없습니다. 설치:  pip install \"scrapling[all]\" && scrapling install && patchright install --force chromium")
    sys.exit(1)


# ─────────────────────────── 파싱 헬퍼 ───────────────────────────

def meta_og(html: str, prop: str):
    for pat in (rf'<meta[^>]+property=["\']og:{prop}["\'][^>]+content=["\']([^"\']*)',
                rf'<meta[^>]+content=["\']([^"\']*)["\'][^>]+property=["\']og:{prop}["\']'):
        m = re.search(pat, html, re.I)
        if m:
            return _html_unescape(m.group(1))
    return None


def _html_unescape(s: str) -> str:
    import html as _h
    return _h.unescape(s) if s else s


def clean_title(raw):
    """og:title = '상품명 - 카테고리 | 쿠팡' → 꼬리표 제거."""
    if not raw:
        return None
    t = raw.strip()
    b = t.rfind(" | 쿠팡")
    if b > 0:
        t = t[:b]
    d = t.rfind(" - ")
    if d > 20:                      # 너무 앞이면 상품명 일부일 수 있어 보존
        t = t[:d]
    return t.strip()


def extract_price(html: str):
    m = re.search(r'"(?:salePrice|couponPrice|finalPrice)"\s*:\s*(\d{3,})', html)
    if m:
        return int(m.group(1)), "판매가(JSON)"
    m = re.search(r'([0-9]{1,3}(?:,[0-9]{3})+)\s*원', html)
    if m:
        return int(m.group(1).replace(",", "")), "표시가격"
    return None, ""


def extract_images(html: str, cap: int = 20):
    imgs, seen = [], set()
    og = meta_og(html, "image")
    if og:
        u = ("https:" + og) if og.startswith("//") else og
        if u not in seen:
            seen.add(u); imgs.append(u)
    for m in re.findall(r'(?:https?:)?//[^"\'\s]*coupangcdn\.com/[^"\'\s]*vendor_inventory[^"\'\s]*\.(?:jpg|jpeg|png|webp)', html, re.I):
        u = ("https:" + m) if m.startswith("//") else m
        if u not in seen:
            seen.add(u); imgs.append(u)
        if len(imgs) >= cap:
            break
    return imgs


def extract_options(html: str):
    """옵션(속성 타입→값). 쿠팡 임베드 패턴 기반 — 상품마다 유무가 다르다."""
    groups = {}
    for m in re.finditer(r'"attributeTypeName"\s*:\s*"([^"]+)"\s*,\s*"attributeValueName"\s*:\s*"([^"]+)"', html):
        t, v = m.group(1).strip(), m.group(2).strip()
        if t and v:
            groups.setdefault(t, [])
            if v not in groups[t]:
                groups[t].append(v)
    return [{"name": k, "values": v} for k, v in groups.items()]


def is_blocked(html: str, status: int) -> bool:
    if status in (403, 428):
        return True
    return any(n in html for n in ("Access Denied", "errors.edgesuite.net")) and len(html) < 5000


def product_id_from(s: str):
    m = re.search(r"/vp/products/(\d+)", s)
    if m:
        return m.group(1)
    return s if s.isdigit() else None


# ─────────────────────────── 수집 ───────────────────────────

def scrape(arg: str, limit: int, wait_s: int, headless: bool, proxy):
    pid = product_id_from(arg)
    is_search = pid is None

    captured = {"search_html": "", "products": []}

    def flow(page: Page):
        print(f"  · 홈 {wait_s}초 예열 (Akamai 챌린지 해결)…", flush=True)
        page.wait_for_timeout(wait_s * 1000)
        # 사람처럼 약간의 상호작용
        for _ in range(2):
            page.mouse.move(200, 400); page.mouse.wheel(0, 350)
            page.wait_for_timeout(800)

        if is_search:
            print(f"  · 검색: {arg}", flush=True)
            page.goto(f"https://www.coupang.com/np/search?q={quote(arg)}", wait_until="domcontentloaded")
            try: page.wait_for_load_state("networkidle", timeout=12000)
            except Exception: pass
            page.wait_for_timeout(2500)
            captured["search_html"] = page.content()
            ids = list(dict.fromkeys(re.findall(r"/vp/products/(\d+)", captured["search_html"])))[:limit]
            print(f"  · 검색 결과 상품 {len(ids)}개 → 상세 수집", flush=True)
        else:
            ids = [pid]

        for i, one in enumerate(ids, 1):
            url = f"https://www.coupang.com/vp/products/{one}"
            print(f"  · [{i}/{len(ids)}] 상세 {one}", flush=True)
            page.goto(url, wait_until="domcontentloaded")
            try: page.wait_for_load_state("networkidle", timeout=12000)
            except Exception: pass
            page.wait_for_timeout(2500)
            captured["products"].append({"id": one, "url": url, "html": page.content()})
        return page

    print("쿠팡 스크래퍼 시작 —", "검색" if is_search else "상품", arg)
    print(f"모드: {'headless' if headless else 'headed(창)'} · real_chrome · wait {wait_s}s"
          + (f" · proxy" if proxy else ""))
    t0 = time.time()
    kwargs = dict(headless=headless, real_chrome=True, humanize=True,
                  network_idle=True, block_webrtc=True, page_action=flow)
    if proxy:
        kwargs["proxy"] = proxy
    StealthyFetcher.fetch("https://www.coupang.com", **kwargs)

    # ── 파싱 ──
    results = []
    for p in captured["products"]:
        html, status = p["html"], 200
        if is_blocked(html, status):
            results.append({"id": p["id"], "url": p["url"], "blocked": True})
            continue
        price, psrc = extract_price(html)
        results.append({
            "id": p["id"],
            "url": p["url"],
            "blocked": False,
            "title": clean_title(meta_og(html, "title")),
            "price": price,
            "price_source": psrc,
            "images": extract_images(html),
            "options": extract_options(html),
        })

    elapsed = time.time() - t0
    search_blocked = is_search and is_blocked(captured["search_html"], 200)
    return {"query": arg, "is_search": is_search, "search_blocked": search_blocked,
            "count": len(results), "elapsed_sec": round(elapsed, 1), "products": results}


def main():
    ap = argparse.ArgumentParser(description="쿠팡 상품 스크래퍼 (Akamai 우회)")
    ap.add_argument("query", help="검색어 또는 상품 ID/URL")
    ap.add_argument("--limit", type=int, default=3, help="검색 시 상세 수집 개수 (기본 3)")
    ap.add_argument("--wait", type=int, default=25, help="홈 예열 초 (기본 25)")
    ap.add_argument("--headless", action="store_true", help="headless (비권장 — 통과율↓)")
    ap.add_argument("--proxy", default=None, help="http://ID:PW@host:port")
    ap.add_argument("--out", default="coupang_result.json", help="결과 JSON 경로")
    a = ap.parse_args()

    data = scrape(a.query, a.limit, a.wait, a.headless, a.proxy)

    print("\n" + "=" * 60)
    if data["search_blocked"]:
        print("⚠ 검색이 차단됨(403) — IP rate-limit. IP 변경(핫스팟/프록시) 또는 쿨다운 후 재시도.")
    for p in data["products"]:
        if p.get("blocked"):
            print(f"  ✗ {p['id']} — 차단됨(403)")
            continue
        print(f"  ✓ {p['id']}")
        print(f"     상품명: {p['title']}")
        print(f"     가격  : {p['price']:,}원 ({p['price_source']})" if p['price'] else "     가격  : (파싱 실패)")
        print(f"     이미지: {len(p['images'])}장")
        if p["options"]:
            for o in p["options"]:
                print(f"     옵션  : {o['name']} = {', '.join(o['values'][:8])}")
    print("=" * 60)
    print(f"총 {data['count']}개 · {data['elapsed_sec']}초")

    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"→ 저장: {a.out}")


if __name__ == "__main__":
    main()
